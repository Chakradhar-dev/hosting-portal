1:"$Sreact.fragment"
2:I[9766,[],""]
3:I[8924,[],""]
4:I[7989,[],"ClientSegmentRoot"]
5:I[5658,["2619","static/chunks/2619-3c9e02e22d10480a.js","7581","static/chunks/app/admin/layout-8f29e145c39d7024.js"],"default"]
7:I[1959,[],"ClientPageRoot"]
8:I[5782,["2619","static/chunks/2619-3c9e02e22d10480a.js","3698","static/chunks/app/admin/page-23e0c65ac22b2a96.js"],"default"]
b:I[4431,[],"OutletBoundary"]
d:I[5278,[],"AsyncMetadataOutlet"]
f:I[4431,[],"ViewportBoundary"]
11:I[4431,[],"MetadataBoundary"]
12:"$Sreact.suspense"
14:I[7150,[],""]
:HL["/_next/static/css/b0b2b8667868f94a.css","style"]
0:{"P":null,"b":"fVuvohzdt_7vudHYj11bp","p":"","c":["","admin"],"i":false,"f":[[["",{"children":["admin",{"children":["__PAGE__",{}]}]},"$undefined","$undefined",true],["",["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/css/b0b2b8667868f94a.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]],["$","html",null,{"lang":"en","className":"h-full bg-slate-50","children":["$","body",null,{"className":"h-full flex flex-col font-sans text-slate-900 antialiased","children":["$","$L2",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L3",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}]}]]}],{"children":["admin",["$","$1","c",{"children":[null,["$","$L4",null,{"Component":"$5","slots":{"children":["$","$L2",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L3",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]},"params":{},"promise":"$@6"}]]}],{"children":["__PAGE__",["$","$1","c",{"children":[["$","$L7",null,{"Component":"$8","searchParams":{},"params":"$0:f:0:1:2:children:1:props:children:1:props:params","promises":["$@9","$@a"]}],null,["$","$Lb",null,{"children":["$Lc",["$","$Ld",null,{"promise":"$@e"}]]}]]}],{},null,false]},null,false]},null,false],["$","$1","h",{"children":[null,[["$","$Lf",null,{"children":"$L10"}],null],["$","$L11",null,{"children":["$","div",null,{"hidden":true,"children":["$","$12",null,{"fallback":null,"children":"$L13"}]}]}]]}],false]],"m":"$undefined","G":["$14",[]],"s":false,"S":true}
6:"$0:f:0:1:2:children:1:props:children:1:props:params"
9:{}
a:"$0:f:0:1:2:children:1:props:children:1:props:params"
10:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
c:null
e:{"metadata":[["$","title","0",{"children":"CloudHost Portal - Next-Gen WHMCS & cPanel Hosting CMS"}],["$","meta","1",{"name":"description","content":"Modern, open-source hosting management portal with automated WHM & cPanel provisioning and 1-click SSO."}]],"error":null,"digest":"$undefined"}
13:"$e:metadata"
